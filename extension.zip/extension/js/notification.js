// var options = {
//   type: "basic",
//   title: "Reminder",
//   message: "Час повторити слова",
//   iconUrl: "image/notif-img.jpg"
// };
//
// chrome.notifications.create(options);
//
// chrome.notifications.onClicked.addListener(callback)
//
// function callback() {
//     window.open('http://www.magiword.zzz.com.ua', '_blank');
// }



// notification.onclick = function(event) {
//   event.preventDefault(); // prevent the browser from focusing the Notification's tab
//
// }
